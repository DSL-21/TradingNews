# Data sources and licensing gates

| Source | MVP role | Integration status | Public display status |
|---|---|---|---|
| GDELT DOC 2.0 | Global headline discovery across financial, geopolitical, energy, and crypto topics | Implemented in the backend | Confirm the current API usage conditions and provide attribution; app shows headline/source/link only |
| Financial Modeling Prep | Economic calendar with Actual / Estimate / Previous | Backend adapter included, disabled by default | Requires the appropriate subscription and the provider's separate Data Display and Licensing Agreement |
| Forex Factory | Candidate economic-calendar source | Not integrated; no unofficial scraping | Obtain written permission before redistribution or public display |
| Marketaux | Candidate financial-news API | Not integrated in v0.1.0 | Confirm display/redistribution rights directly with the provider before enabling a public feed |

The app never treats a provider's public web page, free API key, or downloadable export as automatic permission to redistribute its data in a public mobile application.
