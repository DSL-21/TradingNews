# Trading News — Privacy Policy Template

> Draft template only. Replace all bracketed fields and review it with a qualified adviser before public release.

**Last updated:** [DATE]

**Operator:** [LEGAL NAME / BUSINESS NAME]

**Contact:** [SUPPORT EMAIL]

## Data handled by the app

The current MVP does not require an account and does not include advertising or analytics SDKs. It stores the backend URL and alert preferences locally on the device. If notification permission is granted, Android displays event reminder notifications.

When the app connects to an operator-managed backend, that server receives standard network request metadata (including IP address, request time, and requested endpoint). The backend retrieves market-news metadata from its configured third-party providers. Provider requests and logs are subject to those providers' own privacy terms.

## Purpose and legal basis

[DESCRIBE THE OPERATOR'S PURPOSES AND APPLICABLE GDPR LEGAL BASES, INCLUDING SECURITY LOGGING AND SERVICE DELIVERY.]

## Sharing and processors

[LIST HOSTING PROVIDER, NEWS DATA PROVIDERS, ECONOMIC CALENDAR PROVIDERS, AND ANY OTHER PROCESSORS. DESCRIBE INTERNATIONAL TRANSFERS WHERE APPLICABLE.]

## Retention and deletion

[DESCRIBE SERVER LOG RETENTION, BACKUP RETENTION, AND HOW A USER CAN REQUEST DELETION OF PERSONAL DATA.]

## User rights

Depending on applicable law, users may have rights to access, rectify, erase, restrict, object to processing, and lodge a complaint with a supervisory authority.

## Security

The production service should use HTTPS, restricted server access, secret management, security updates, and a documented incident response process.

## Changes

Material changes to this policy will be published at [PRIVACY POLICY URL].
