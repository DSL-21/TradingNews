# Keep app defaults. Add provider-specific rules if a serializer or obfuscation is introduced.
