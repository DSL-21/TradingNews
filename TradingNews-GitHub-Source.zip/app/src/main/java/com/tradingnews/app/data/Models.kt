package com.tradingnews.app.data

import java.time.Instant
import java.time.OffsetDateTime
import java.time.format.DateTimeParseException

const val IMPACT_CRITICAL = "CRITICAL"
const val IMPACT_HIGH = "HIGH"
const val IMPACT_MEDIUM = "MEDIUM"
const val IMPACT_LOW = "LOW"

const val CATEGORY_MARKETS = "markets"
const val CATEGORY_GEOPOLITICS = "geopolitics"
const val CATEGORY_ENERGY = "energy"
const val CATEGORY_CRYPTO = "crypto"
const val CATEGORY_COMPANIES = "companies"
const val CATEGORY_OTHER = "other"

data class EconomicEvent(
    val id: String,
    val title: String,
    val currency: String,
    val country: String,
    val time: String,
    val impact: String,
    val actual: String = "—",
    val forecast: String = "—",
    val previous: String = "—",
    val isDemo: Boolean = false
)

data class NewsItem(
    val id: String,
    val title: String,
    val source: String,
    val publishedAt: String,
    val url: String,
    val category: String,
    val impact: String,
    val summary: String = "",
    val isDemo: Boolean = false
)

data class FeedSnapshot(
    val events: List<EconomicEvent>,
    val news: List<NewsItem>,
    val calendarLive: Boolean,
    val newsLive: Boolean,
    val statusMessage: String
)

fun parseInstantOrNull(value: String): Instant? {
    return try {
        Instant.parse(value)
    } catch (_: DateTimeParseException) {
        try {
            OffsetDateTime.parse(value).toInstant()
        } catch (_: DateTimeParseException) {
            null
        }
    }
}
