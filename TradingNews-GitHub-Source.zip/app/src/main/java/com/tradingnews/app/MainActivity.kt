package com.tradingnews.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Timelapse
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.tradingnews.app.data.CATEGORY_CRYPTO
import com.tradingnews.app.data.CATEGORY_ENERGY
import com.tradingnews.app.data.CATEGORY_GEOPOLITICS
import com.tradingnews.app.data.CATEGORY_MARKETS
import com.tradingnews.app.data.EconomicEvent
import com.tradingnews.app.data.NewsItem
import com.tradingnews.app.data.parseInstantOrNull
import com.tradingnews.app.notifications.NotificationHelper
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val AppBackground = Color(0xFF0B1017)
private val Panel = Color(0xFF121B25)
private val PanelRaised = Color(0xFF192634)
private val Border = Color(0xFF263544)
private val TextMain = Color(0xFFE8F0F4)
private val TextMuted = Color(0xFF91A4B3)
private val Accent = Color(0xFF35D6B0)
private val Danger = Color(0xFFFF647C)
private val Warning = Color(0xFFFFB454)
private val Blue = Color(0xFF79AFFF)

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<TradingNewsViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        setContent {
            TradingNewsTheme {
                TradingNewsApp(viewModel)
            }
        }
    }
}

private enum class AppTab(val title: String) {
    HOME("Přehled"), CALENDAR("Kalendář"), NEWS("Zprávy"), SETTINGS("Nastavení")
}

@Composable
private fun TradingNewsTheme(content: @Composable () -> Unit) {
    val scheme = androidx.compose.material3.darkColorScheme(
        primary = Accent,
        onPrimary = Color(0xFF06231D),
        secondary = Blue,
        background = AppBackground,
        onBackground = TextMain,
        surface = Panel,
        onSurface = TextMain,
        surfaceVariant = PanelRaised,
        onSurfaceVariant = TextMuted,
        outline = Border,
        error = Danger
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun TradingNewsApp(viewModel: TradingNewsViewModel) {
    val state = viewModel.uiState
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.HOME) }

    Scaffold(
        containerColor = AppBackground,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF101821), contentColor = TextMuted) {
                AppTab.entries.forEach { tab ->
                    val icon = when (tab) {
                        AppTab.HOME -> Icons.Outlined.ShowChart
                        AppTab.CALENDAR -> Icons.Outlined.CalendarMonth
                        AppTab.NEWS -> Icons.Outlined.Newspaper
                        AppTab.SETTINGS -> Icons.Outlined.Settings
                    }
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(icon, contentDescription = tab.title) },
                        label = { Text(tab.title, fontSize = 10.sp) },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(AppBackground)
                .padding(padding)
        ) {
            AppHeader(
                newsLive = state.newsLive,
                calendarLive = state.calendarLive,
                refreshing = state.isRefreshing,
                onRefresh = viewModel::refresh
            )
            if (!state.newsLive || !state.calendarLive) {
                StatusBanner(state.statusMessage)
            }
            when (selectedTab) {
                AppTab.HOME -> DashboardScreen(state, onCalendar = { selectedTab = AppTab.CALENDAR }, onNews = { selectedTab = AppTab.NEWS })
                AppTab.CALENDAR -> CalendarScreen(state.events)
                AppTab.NEWS -> NewsScreen(state.news)
                AppTab.SETTINGS -> SettingsScreen(
                    state = state,
                    onSaveApi = viewModel::saveApiBaseUrl,
                    onRefresh = viewModel::refresh,
                    onReminderChanged = viewModel::setReminderEnabled
                )
            }
        }
    }
}

@Composable
private fun AppHeader(newsLive: Boolean, calendarLive: Boolean, refreshing: Boolean, onRefresh: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(Accent.copy(alpha = 0.13f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.ShowChart, contentDescription = null, tint = Accent, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("TRADING NEWS", fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = TextMain)
                Text("MARKET INTELLIGENCE", fontSize = 9.sp, letterSpacing = 1.4.sp, color = TextMuted)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                StatusDot("NEWS", newsLive)
                StatusDot("CALENDAR", calendarLive)
            }
            TextButton(onClick = onRefresh, contentPadding = PaddingValues(4.dp)) {
                if (refreshing) {
                    CircularProgressIndicator(modifier = Modifier.size(19.dp), strokeWidth = 2.dp, color = Accent)
                } else {
                    Icon(Icons.Outlined.Refresh, contentDescription = "Aktualizovat", tint = TextMuted)
                }
            }
        }
    }
}

@Composable
private fun StatusDot(label: String, live: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(6.dp).background(if (live) Accent else Warning, CircleShape))
        Text(if (live) "$label LIVE" else "$label DEMO", fontSize = 8.sp, letterSpacing = 0.5.sp, color = if (live) Accent else Warning, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatusBanner(message: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .background(Color(0xFF272116), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Outlined.Language, contentDescription = null, tint = Warning, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(message, color = Color(0xFFE8D5AE), fontSize = 11.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DashboardScreen(
    state: TradingNewsUiState,
    onCalendar: () -> Unit,
    onNews: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 17.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("MARKET OVERVIEW", fontSize = 11.sp, color = TextMuted, letterSpacing = 1.5.sp, fontWeight = FontWeight.SemiBold)
                Text("Nenech si ujít událost,\nkterá hýbe trhem.", fontSize = 25.sp, color = TextMain, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
            }
        }
        item {
            val nextEvent = state.events.minByOrNull { parseInstantOrNull(it.time) ?: Instant.MAX }
            NextEventCard(nextEvent)
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                SectionTitle("NADCHÁZEJÍCÍ UDÁLOSTI", "Ekonomický kalendář")
                TextButton(onClick = onCalendar) { Text("Vše", color = Accent, fontSize = 12.sp) }
            }
        }
        if (state.isLoading) {
            item { LoadingPanel() }
        } else {
            items(state.events.take(3), key = { it.id }) { event -> EventCard(event) }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                SectionTitle("BREAKING NEWS", "Události z finančních trhů")
                TextButton(onClick = onNews) { Text("Vše", color = Accent, fontSize = 12.sp) }
            }
        }
        items(state.news.take(3), key = { it.id }) { news -> NewsCard(news) }
        item { DisclaimerLine() }
    }
}

@Composable
private fun NextEventCard(event: EconomicEvent?) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF142B2B)),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Icon(Icons.Outlined.Timelapse, tint = Accent, contentDescription = null, modifier = Modifier.size(17.dp))
                    Text("NEXT MARKET EVENT", fontSize = 10.sp, letterSpacing = 1.2.sp, color = Accent, fontWeight = FontWeight.Bold)
                }
                if (event?.isDemo == true) SmallBadge("DEMO", Warning)
            }
            if (event == null) {
                Text("Žádná nadcházející událost", color = TextMain, fontWeight = FontWeight.SemiBold)
            } else {
                Text(event.title, fontSize = 21.sp, color = TextMain, fontWeight = FontWeight.Bold, lineHeight = 25.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(event.currency, color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("•", color = TextMuted)
                    Text(event.country, color = TextMuted, fontSize = 12.sp)
                    Text("•", color = TextMuted)
                    ImpactBadge(event.impact)
                }
                HorizontalDivider(color = Color(0xFF28504A))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("LOKÁLNÍ ČAS", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                        Text(formatDateTime(event.time), color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("FORECAST", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                        Text(event.forecast, color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarScreen(events: List<EconomicEvent>) {
    var selectedImpact by rememberSaveable { mutableStateOf("ALL") }
    var selectedCurrency by rememberSaveable { mutableStateOf("ALL") }
    val filtered = events.filter { event ->
        (selectedImpact == "ALL" || event.impact == selectedImpact) &&
            (selectedCurrency == "ALL" || event.currency == selectedCurrency)
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("ECONOMIC CALENDAR", "Přehled plánovaných makro událostí")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW").forEach { impact ->
                    FilterChip(
                        selected = selectedImpact == impact,
                        onClick = { selectedImpact = impact },
                        label = { Text(if (impact == "ALL") "Vše" else impact, fontSize = 10.sp) }
                    )
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("ALL", "USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "NZD").forEach { currency ->
                    FilterChip(
                        selected = selectedCurrency == currency,
                        onClick = { selectedCurrency = currency },
                        label = { Text(currency, fontSize = 10.sp) }
                    )
                }
            }
        }
        if (filtered.isEmpty()) {
            EmptyState("Žádné události", "Změň filtry nebo aktualizuj data.")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(filtered, key = { it.id }) { EventCard(it, showDetails = true) }
            }
        }
    }
}

@Composable
private fun NewsScreen(news: List<NewsItem>) {
    var selectedCategory by rememberSaveable { mutableStateOf("all") }
    val filtered = news.filter { selectedCategory == "all" || it.category == selectedCategory }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("BREAKING NEWS", "Finanční, geopolitické a tržní události")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(
                    "all" to "Vše",
                    CATEGORY_MARKETS to "Markets",
                    CATEGORY_GEOPOLITICS to "Geopolitics",
                    CATEGORY_ENERGY to "Energy",
                    CATEGORY_CRYPTO to "Crypto"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = selectedCategory == key,
                        onClick = { selectedCategory = key },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
        if (filtered.isEmpty()) {
            EmptyState("Žádné zprávy", "Pro vybranou kategorii nejsou dostupné položky.")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(filtered, key = { it.id }) { NewsCard(it, expanded = true) }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    state: TradingNewsUiState,
    onSaveApi: (String) -> Unit,
    onRefresh: () -> Unit,
    onReminderChanged: (Int, Boolean) -> Unit
) {
    var apiUrl by remember(state.apiBaseUrl) { mutableStateOf(state.apiBaseUrl) }
    val context = LocalContext.current
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val permissionGranted = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 17.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item { SectionTitle("NASTAVENÍ", "Připojení zdrojů a upozornění") }
        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.Language, tint = Accent, contentDescription = null)
                        Text("Backend server", color = TextMain, fontWeight = FontWeight.SemiBold)
                    }
                    Text("Adresa HTTPS serveru, který agreguje zprávy a ekonomický kalendář. API klíče zůstávají na serveru a nejsou součástí APK.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                    OutlinedTextField(
                        value = apiUrl,
                        onValueChange = { apiUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("https://api.example.com") },
                        placeholder = { Text("Nech prázdné pro demo režim") }
                    )
                    Button(onClick = { onSaveApi(apiUrl) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Uložit a připojit")
                    }
                    TextButton(onClick = onRefresh, modifier = Modifier.align(Alignment.End)) { Text("Aktualizovat data", color = Accent) }
                }
            }
        }
        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.NotificationsActive, tint = Accent, contentDescription = null)
                        Text("Upozornění před událostí", color = TextMain, fontWeight = FontWeight.SemiBold)
                    }
                    Text("Upozornění se plánují pouze pro živé události z připojeného backendu. Android může doručení zpozdit kvůli úspoře baterie.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                    if (!permissionGranted) {
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= 33) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Povolit systémová upozornění") }
                    }
                    listOf(60, 15, 5).forEach { minutes ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("$minutes minut před událostí", color = TextMain, fontSize = 13.sp)
                            Switch(
                                checked = minutes in state.reminderMinutes,
                                onCheckedChange = { onReminderChanged(minutes, it) }
                            )
                        }
                    }
                }
            }
        }
        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("ZDROJE DAT", color = TextMain, fontWeight = FontWeight.SemiBold)
                    SourceRow("GDELT DOC 2.0", "Globální zpravodajské pokrytí", state.newsLive)
                    HorizontalDivider(color = Border)
                    SourceRow("Economic calendar API", "Vyžaduje aktivovaného licencovaného poskytovatele", state.calendarLive)
                    HorizontalDivider(color = Border)
                    Text("Forex Factory není v této veřejné verzi stahován neoficiálním exportem. Po ověření licence lze doplnit samostatný konektor.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    val context = LocalContext.current
                    TextButton(
                        onClick = {
                            runCatching {
                                context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://www.forexfactory.com/calendar")))
                            }
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) { Text("Otevřít Forex Factory", color = Accent) }
                }
            }
        }
        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("O APLIKACI", color = TextMain, fontWeight = FontWeight.SemiBold)
                    Text("Trading News • verze 0.1.0", color = TextMuted, fontSize = 12.sp)
                    Text("Informační nástroj. Klasifikace dopadu a sentimentu jsou orientační a nepředstavují obchodní doporučení. Před rozhodnutím ověř událost u původního vydavatele.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("Stav: ${state.statusMessage}", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun SourceRow(name: String, description: String, live: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(name, color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(description, color = TextMuted, fontSize = 10.sp)
        }
        SmallBadge(if (live) "LIVE" else "DEMO", if (live) Accent else Warning)
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp)) { content() }
    }
}

@Composable
private fun EventCard(event: EconomicEvent, showDetails: Boolean = false) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(event.currency, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("•", color = TextMuted)
                    Text(event.country, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (event.isDemo) SmallBadge("DEMO", Warning)
                    ImpactBadge(event.impact)
                }
            }
            Text(event.title, fontSize = 15.sp, color = TextMain, fontWeight = FontWeight.SemiBold, lineHeight = 19.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(formatDateTime(event.time), color = TextMuted, fontSize = 11.sp)
                Text("Forecast  ${event.forecast}", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
            if (showDetails) {
                HorizontalDivider(color = Border)
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Metric("ACTUAL", event.actual)
                    Metric("FORECAST", event.forecast)
                    Metric("PREVIOUS", event.previous)
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = TextMuted, fontSize = 8.sp, letterSpacing = 0.8.sp)
        Text(value, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NewsCard(news: NewsItem, expanded: Boolean = false) {
    val context = LocalContext.current
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                runCatching {
                    context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(news.url)))
                }
            }
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                CategoryBadge(news.category)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (news.isDemo) SmallBadge("DEMO", Warning)
                    ImpactBadge(news.impact)
                }
            }
            Text(news.title, color = TextMain, fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold)
            if (expanded && news.summary.isNotBlank()) {
                Text(news.summary, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("${news.source}  •  ${relativeTime(news.publishedAt)}", color = TextMuted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Icon(Icons.Outlined.ChevronRight, contentDescription = "Otevřít zdroj", tint = Accent, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
        Text(subtitle, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ImpactBadge(impact: String) {
    val color = impactColor(impact)
    Surface(color = color.copy(alpha = 0.13f), shape = RoundedCornerShape(50)) {
        Text(impact, color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
    }
}

@Composable
private fun SmallBadge(label: String, color: Color) {
    Surface(color = color.copy(alpha = 0.14f), shape = RoundedCornerShape(5.dp)) {
        Text(label, color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
    }
}

@Composable
private fun CategoryBadge(category: String) {
    val label = when (category.lowercase()) {
        CATEGORY_MARKETS -> "MARKETS"
        CATEGORY_GEOPOLITICS -> "GEOPOLITICS"
        CATEGORY_ENERGY -> "ENERGY"
        CATEGORY_CRYPTO -> "CRYPTO"
        "companies" -> "COMPANIES"
        else -> "WORLD"
    }
    val color = when (category.lowercase()) {
        CATEGORY_GEOPOLITICS -> Danger
        CATEGORY_ENERGY -> Warning
        CATEGORY_CRYPTO -> Blue
        else -> Accent
    }
    SmallBadge(label, color)
}

@Composable
private fun LoadingPanel() {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(color = Accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Načítám přehled…", color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EmptyState(title: String, description: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Icon(Icons.Outlined.Newspaper, contentDescription = null, tint = TextMuted, modifier = Modifier.size(30.dp))
        Text(title, color = TextMain, fontWeight = FontWeight.SemiBold)
        Text(description, color = TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun DisclaimerLine() {
    Text(
        "Trading News je informační nástroj. Upozornění na událost není signál k nákupu ani prodeji.",
        color = TextMuted,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        modifier = Modifier.padding(top = 5.dp, bottom = 6.dp)
    )
}

private fun impactColor(impact: String): Color = when (impact.uppercase()) {
    "CRITICAL" -> Danger
    "HIGH" -> Warning
    "MEDIUM" -> Blue
    else -> TextMuted
}

private fun formatDateTime(value: String): String {
    val instant = parseInstantOrNull(value) ?: return value
    val formatter = DateTimeFormatter.ofPattern("EEE dd.MM.  HH:mm", Locale.getDefault()).withZone(ZoneId.systemDefault())
    return formatter.format(instant)
}

private fun relativeTime(value: String): String {
    val instant = parseInstantOrNull(value) ?: return "čas neznámý"
    val minutes = Duration.between(instant, Instant.now()).toMinutes().coerceAtLeast(0)
    return when {
        minutes < 1 -> "právě teď"
        minutes < 60 -> "před ${minutes} min"
        minutes < 24 * 60 -> "před ${minutes / 60} h"
        else -> "před ${minutes / (24 * 60)} d"
    }
}
