package com.tradingnews.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.tradingnews.app.MainActivity
import com.tradingnews.app.R
import com.tradingnews.app.data.EconomicEvent
import com.tradingnews.app.data.parseInstantOrNull
import java.util.concurrent.TimeUnit

object NotificationHelper {
    const val CHANNEL_ID = "trading_news_events"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Trading event reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Upozornění před ekonomickými událostmi"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun notifyEvent(context: Context, title: String, body: String, notificationId: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val launchIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_trading_news)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
}

object ReminderScheduler {
    fun cancelAll(context: Context) {
        WorkManager.getInstance(context).cancelAllWorkByTag("event-reminder")
    }

    fun cancelInterval(context: Context, events: List<EconomicEvent>, minutesBefore: Int) {
        val manager = WorkManager.getInstance(context)
        events.forEach { event ->
            manager.cancelUniqueWork("event-${event.id}-before-$minutesBefore")
        }
    }

    fun schedule(context: Context, event: EconomicEvent, minutesBefore: Int) {
        val instant = parseInstantOrNull(event.time) ?: return
        val delayMs = instant.toEpochMilli() - System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(minutesBefore.toLong())
        if (delayMs <= 0L || delayMs > TimeUnit.DAYS.toMillis(8)) return

        val work = OneTimeWorkRequestBuilder<EventReminderWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .addTag("event-reminder")
            .setInputData(
                androidx.work.workDataOf(
                    "event_id" to event.id,
                    "event_title" to event.title,
                    "event_currency" to event.currency,
                    "minutes_before" to minutesBefore
                )
            )
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "event-${event.id}-before-$minutesBefore",
            ExistingWorkPolicy.REPLACE,
            work
        )
    }
}

class EventReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        NotificationHelper.createChannel(applicationContext)
        val eventTitle = inputData.getString("event_title") ?: return Result.failure()
        val currency = inputData.getString("event_currency") ?: ""
        val minutes = inputData.getInt("minutes_before", 15)
        val title = "$currency • $eventTitle"
        val body = "Ekonomická událost vychází přibližně za $minutes min. Ověř si aktuální tržní podmínky."
        NotificationHelper.notifyEvent(applicationContext, title, body, (inputData.getString("event_id") ?: eventTitle).hashCode())
        return Result.success()
    }
}
