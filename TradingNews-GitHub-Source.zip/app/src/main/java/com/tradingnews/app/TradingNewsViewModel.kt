package com.tradingnews.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewModelScope
import com.tradingnews.app.data.EconomicEvent
import com.tradingnews.app.data.FeedSnapshot
import com.tradingnews.app.data.NewsItem
import com.tradingnews.app.data.TradingNewsRepository
import com.tradingnews.app.notifications.ReminderScheduler
import kotlinx.coroutines.launch


data class TradingNewsUiState(
    val events: List<EconomicEvent> = emptyList(),
    val news: List<NewsItem> = emptyList(),
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val calendarLive: Boolean = false,
    val newsLive: Boolean = false,
    val statusMessage: String = "Načítám data…",
    val apiBaseUrl: String = "",
    val reminderMinutes: Set<Int> = setOf(15, 5)
)

class TradingNewsViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = application.getSharedPreferences("trading_news_settings", Context.MODE_PRIVATE)
    private val repository = TradingNewsRepository(application)

    var uiState by androidx.compose.runtime.mutableStateOf(
        TradingNewsUiState(
            apiBaseUrl = preferences.getString("api_base_url", "").orEmpty(),
            reminderMinutes = loadReminderMinutes()
        )
    )
        private set

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            uiState = uiState.copy(isLoading = uiState.events.isEmpty(), isRefreshing = true)
            val snapshot = repository.load(uiState.apiBaseUrl)
            applySnapshot(snapshot)
        }
    }

    private fun applySnapshot(snapshot: FeedSnapshot) {
        ReminderScheduler.cancelAll(getApplication())
        uiState = uiState.copy(
            events = snapshot.events,
            news = snapshot.news,
            isLoading = false,
            isRefreshing = false,
            calendarLive = snapshot.calendarLive,
            newsLive = snapshot.newsLive,
            statusMessage = snapshot.statusMessage
        )
        if (snapshot.calendarLive) {
            snapshot.events.forEach { event ->
                uiState.reminderMinutes.forEach { minutes ->
                    ReminderScheduler.schedule(getApplication(), event, minutes)
                }
            }
        }
    }

    fun saveApiBaseUrl(value: String) {
        val cleaned = value.trim().trimEnd('/')
        if (cleaned.isNotEmpty() && !cleaned.startsWith("https://")) {
            uiState = uiState.copy(statusMessage = "Použij zabezpečenou HTTPS adresu backendu.")
            return
        }
        preferences.edit().putString("api_base_url", cleaned).apply()
        uiState = uiState.copy(apiBaseUrl = cleaned)
        refresh()
    }

    fun setReminderEnabled(minutes: Int, enabled: Boolean) {
        val updated = uiState.reminderMinutes.toMutableSet().apply {
            if (enabled) add(minutes) else remove(minutes)
        }
        preferences.edit().putStringSet("reminder_minutes", updated.map(Int::toString).toSet()).apply()
        uiState = uiState.copy(reminderMinutes = updated)
        if (uiState.calendarLive && enabled) {
            uiState.events.forEach { ReminderScheduler.schedule(getApplication(), it, minutes) }
        } else if (!enabled) {
            ReminderScheduler.cancelInterval(getApplication(), uiState.events, minutes)
        }
    }

    private fun loadReminderMinutes(): Set<Int> {
        val stored = preferences.getStringSet("reminder_minutes", null)
        if (stored == null) return setOf(15, 5)
        return stored.mapNotNull { it.toIntOrNull() }.filter { it in setOf(60, 15, 5) }.toSet()
    }
}
