package com.tradingnews.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.temporal.ChronoUnit

class TradingNewsRepository(private val context: Context) {
    suspend fun load(baseUrl: String): FeedSnapshot = withContext(Dispatchers.IO) {
        if (baseUrl.isBlank()) {
            return@withContext DemoData.snapshot("Zadej adresu backendu v Nastavení. Zobrazuji ukázková data.")
        }

        val normalizedBase = baseUrl.trim().trimEnd('/')
        val newsPayload = getJson("$normalizedBase/v1/news?category=all")
        val calendarPayload = getJson("$normalizedBase/v1/calendar?range=7d")

        val parsedNews = newsPayload?.let(::parseNews).orEmpty()
        val parsedEvents = calendarPayload?.let(::parseEvents).orEmpty()
        val newsLive = newsPayload?.optBoolean("live", false) == true
        val calendarLive = calendarPayload?.optBoolean("live", false) == true

        val news = if (parsedNews.isNotEmpty()) parsedNews else DemoData.news()
        val events = if (parsedEvents.isNotEmpty()) parsedEvents else DemoData.events()
        val status = when {
            newsLive && calendarLive -> "Živá data: zprávy i ekonomický kalendář."
            newsLive -> "Živé zprávy jsou dostupné. Kalendář zatím používá ukázková data."
            calendarLive -> "Živý ekonomický kalendář je dostupný. Zprávy zatím používají ukázková data."
            else -> "Backend nevrátil živá data. Zobrazuji ukázkový obsah."
        }
        FeedSnapshot(events, news, calendarLive, newsLive, status)
    }

    private fun getJson(urlString: String): JSONObject? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 12_000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "TradingNews-Android/0.1")
            }
            if (connection.responseCode !in 200..299) return null
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            JSONObject(body)
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun parseNews(root: JSONObject): List<NewsItem> {
        val array = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val title = item.optString("title").trim()
                val url = item.optString("url").trim()
                if (title.isBlank() || url.isBlank()) continue
                add(
                    NewsItem(
                        id = item.optString("id", url.hashCode().toString()),
                        title = title,
                        source = item.optString("source", "News source"),
                        publishedAt = item.optString("published_at", ""),
                        url = url,
                        category = item.optString("category", CATEGORY_OTHER),
                        impact = normalizeImpact(item.optString("impact", IMPACT_MEDIUM)),
                        summary = item.optString("summary", "")
                    )
                )
            }
        }
    }

    private fun parseEvents(root: JSONObject): List<EconomicEvent> {
        val array = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val title = item.optString("title").trim()
                val time = item.optString("time").trim()
                if (title.isBlank() || time.isBlank()) continue
                add(
                    EconomicEvent(
                        id = item.optString("id", "$title-$time"),
                        title = title,
                        currency = item.optString("currency", "—"),
                        country = item.optString("country", ""),
                        time = time,
                        impact = normalizeImpact(item.optString("impact", IMPACT_MEDIUM)),
                        actual = item.optString("actual", "—"),
                        forecast = item.optString("forecast", "—"),
                        previous = item.optString("previous", "—")
                    )
                )
            }
        }
    }

    private fun normalizeImpact(value: String): String = when (value.uppercase()) {
        "CRITICAL", "EXTREME" -> IMPACT_CRITICAL
        "HIGH" -> IMPACT_HIGH
        "MEDIUM", "MODERATE" -> IMPACT_MEDIUM
        else -> IMPACT_LOW
    }
}

object DemoData {
    fun snapshot(message: String = "Ukázkový režim") = FeedSnapshot(
        events = events(),
        news = news(),
        calendarLive = false,
        newsLive = false,
        statusMessage = message
    )

    fun events(): List<EconomicEvent> {
        val now = Instant.now()
        return listOf(
            demoEvent("demo-cpi", "US CPI m/m", "USD", "United States", now.plus(2, ChronoUnit.HOURS), IMPACT_CRITICAL, "0.3%", "0.2%", "0.3%"),
            demoEvent("demo-fed", "FOMC Interest Rate Decision", "USD", "United States", now.plus(7, ChronoUnit.HOURS), IMPACT_CRITICAL, "—", "4.00%", "4.00%"),
            demoEvent("demo-gdp", "GDP q/q", "EUR", "Euro Area", now.plus(22, ChronoUnit.HOURS), IMPACT_HIGH, "—", "0.2%", "0.2%"),
            demoEvent("demo-pmi", "Services PMI", "GBP", "United Kingdom", now.plus(29, ChronoUnit.HOURS), IMPACT_MEDIUM, "—", "51.4", "51.2")
        )
    }

    private fun demoEvent(
        id: String, title: String, currency: String, country: String,
        time: Instant, impact: String, actual: String, forecast: String, previous: String
    ) = EconomicEvent(
        id = id, title = title, currency = currency, country = country,
        time = time.toString(), impact = impact, actual = actual,
        forecast = forecast, previous = previous, isDemo = true
    )

    fun news(): List<NewsItem> {
        val now = Instant.now()
        return listOf(
            demoNews("demo-news-1", "Central banks in focus as markets reassess rate expectations", "Trading News Demo", now.minus(8, ChronoUnit.MINUTES), CATEGORY_MARKETS, IMPACT_HIGH),
            demoNews("demo-news-2", "Energy markets monitor new supply risks and shipping disruption", "Trading News Demo", now.minus(31, ChronoUnit.MINUTES), CATEGORY_ENERGY, IMPACT_HIGH),
            demoNews("demo-news-3", "Officials signal further diplomatic talks amid regional tensions", "Trading News Demo", now.minus(54, ChronoUnit.MINUTES), CATEGORY_GEOPOLITICS, IMPACT_CRITICAL),
            demoNews("demo-news-4", "Digital asset markets await regulatory update", "Trading News Demo", now.minus(96, ChronoUnit.MINUTES), CATEGORY_CRYPTO, IMPACT_MEDIUM)
        )
    }

    private fun demoNews(id: String, title: String, source: String, time: Instant, category: String, impact: String) = NewsItem(
        id = id,
        title = title,
        source = source,
        publishedAt = time.toString(),
        url = "https://www.gdeltproject.org/",
        category = category,
        impact = impact,
        summary = "Ilustrační položka pro návrh aplikace. Nejde o aktuální zprávu.",
        isDemo = true
    )
}
