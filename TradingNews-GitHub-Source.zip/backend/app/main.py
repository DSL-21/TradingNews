from __future__ import annotations

import hashlib
import os
import re
import time
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urlparse
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Trading News API",
    version="0.1.0",
    description="Server-side aggregation API for the Trading News Android application.",
)

# The backend is intended to run behind HTTPS. CORS is open for the first prototype;
# narrow allow_origins before a public production deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in os.getenv("CORS_ORIGINS", "*").split(",") if origin.strip()],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

GDELT_DOC_URL = "https://api.gdeltproject.org/api/v2/doc/doc"
FMP_CALENDAR_URL = "https://financialmodelingprep.com/stable/economic-calendar"
CACHE: dict[str, tuple[float, Any]] = {}
CACHE_SECONDS = int(os.getenv("CACHE_SECONDS", "180"))

NEWS_QUERIES = {
    "all": '(inflation OR "central bank" OR "interest rate" OR "monetary policy" OR "stock market" OR forex OR currency OR bonds OR "oil price" OR OPEC OR "natural gas" OR gold OR war OR conflict OR sanctions OR tariffs OR election OR bitcoin OR cryptocurrency OR "company earnings" OR bankruptcy OR "banking crisis")',
    "markets": '("stock market" OR forex OR currency OR bonds OR "central bank" OR inflation OR "interest rate" OR "monetary policy")',
    "geopolitics": '(war OR conflict OR invasion OR sanctions OR tariffs OR election OR coup OR missile OR blockade OR ceasefire)',
    "energy": '("oil price" OR OPEC OR "natural gas" OR LNG OR energy OR pipeline OR refinery)',
    "crypto": '(bitcoin OR ethereum OR cryptocurrency OR "crypto exchange" OR "crypto regulation" OR blockchain)',
}


def cache_get(key: str) -> Any | None:
    entry = CACHE.get(key)
    if not entry:
        return None
    expires_at, value = entry
    if expires_at <= time.time():
        CACHE.pop(key, None)
        return None
    return value


def cache_set(key: str, value: Any) -> None:
    CACHE[key] = (time.time() + CACHE_SECONDS, value)


def classify_category(text: str) -> str:
    value = text.lower()
    if any(term in value for term in ("bitcoin", "ethereum", "crypto", "cryptocurrency", "blockchain")):
        return "crypto"
    if any(term in value for term in ("opec", "oil", "gas price", "lng", "pipeline", "refinery", "energy")):
        return "energy"
    if any(term in value for term in ("war", "conflict", "missile", "sanction", "invasion", "tariff", "ceasefire", "geopolit")):
        return "geopolitics"
    if any(term in value for term in ("earnings", "profit warning", "merger", "acquisition", "bankruptcy", "quarterly results")):
        return "companies"
    if any(term in value for term in ("inflation", "central bank", "interest rate", "stock", "bond", "forex", "currency", "market", "federal reserve", "ecb")):
        return "markets"
    return "other"


def classify_impact(text: str) -> str:
    value = text.lower()
    if any(term in value for term in ("invasion", "war declared", "emergency rate", "bank collapse", "default", "major escalation", "nuclear")):
        return "CRITICAL"
    if any(term in value for term in ("inflation", "central bank", "interest rate", "opec", "sanction", "tariff", "ceasefire", "missile", "earnings warning", "banking crisis")):
        return "HIGH"
    if any(term in value for term in ("market", "stocks", "bonds", "bitcoin", "crypto", "oil", "currency", "company")):
        return "MEDIUM"
    return "LOW"


def parse_gdelt_date(value: str) -> str:
    # GDELT DOC timestamps are usually formatted like 20261110T104500Z.
    try:
        parsed = datetime.strptime(value, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
        return parsed.isoformat()
    except (TypeError, ValueError):
        return datetime.now(timezone.utc).isoformat()


def safe_article_url(value: str) -> bool:
    parsed = urlparse(value or "")
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


async def fetch_gdelt_news(category: str) -> dict[str, Any]:
    category = category if category in NEWS_QUERIES else "all"
    cache_key = f"news:{category}"
    cached = cache_get(cache_key)
    if cached is not None:
        return cached

    params = {
        "query": NEWS_QUERIES[category],
        "mode": "artlist",
        "format": "json",
        "maxrecords": "60",
        "sort": "datedesc",
        "timespan": "24h",
    }
    timeout = httpx.Timeout(18.0, connect=8.0)
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        response = await client.get(GDELT_DOC_URL, params=params, headers={"User-Agent": "TradingNews/0.1 (+market-news aggregator)"})
        response.raise_for_status()
        payload = response.json()

    articles = payload.get("articles", []) if isinstance(payload, dict) else []
    output: list[dict[str, Any]] = []
    seen: set[str] = set()
    for article in articles:
        if not isinstance(article, dict):
            continue
        title = re.sub(r"\s+", " ", str(article.get("title", ""))).strip()
        url = str(article.get("url", "")).strip()
        if not title or not safe_article_url(url) or url in seen:
            continue
        seen.add(url)
        domain = str(article.get("domain", "")).strip() or urlparse(url).netloc
        published = parse_gdelt_date(str(article.get("seendate", "")))
        resolved_category = classify_category(title)
        output.append(
            {
                "id": hashlib.sha1(url.encode("utf-8")).hexdigest()[:16],
                "title": title,
                "source": domain,
                "published_at": published,
                "url": url,
                "category": resolved_category,
                "impact": classify_impact(title),
                "summary": "Open the original publisher article. Headline and source are supplied through GDELT DOC.",
            }
        )

    result = {
        "source": "GDELT DOC 2.0",
        "live": True,
        "retrieved_at": datetime.now(timezone.utc).isoformat(),
        "data": output,
        "notice": "Headlines link to the original publisher. Article content remains with its publisher.",
    }
    cache_set(cache_key, result)
    return result


def calendar_provider_status() -> tuple[bool, str]:
    key_present = bool(os.getenv("FMP_API_KEY"))
    licensed = os.getenv("FMP_DATA_DISPLAY_LICENSED", "false").lower() == "true"
    timezone_name = os.getenv("FMP_EVENT_TIMEZONE", "").strip()
    if not key_present:
        return False, "Ekonomický kalendář není připojen: chybí FMP_API_KEY."
    if not licensed:
        return False, "Ekonomický kalendář je vypnutý do potvrzení práva na veřejné zobrazování dat (FMP_DATA_DISPLAY_LICENSED=true)."
    if not timezone_name:
        return False, "Nastav FMP_EVENT_TIMEZONE až po potvrzení časové zóny časových údajů poskytovatele."
    try:
        ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError:
        return False, "FMP_EVENT_TIMEZONE není platná IANA časová zóna."
    return True, "Licensed FMP calendar configured."


async def fetch_fmp_calendar(days: int = 7) -> dict[str, Any]:
    enabled, notice = calendar_provider_status()
    if not enabled:
        return {
            "source": "FMP Economic Calendar",
            "live": False,
            "data": [],
            "notice": notice,
        }

    days = min(max(days, 1), 14)
    start_date = datetime.now(timezone.utc).date()
    end_date = start_date + timedelta(days=days)
    params = {
        "from": start_date.isoformat(),
        "to": end_date.isoformat(),
        "apikey": os.environ["FMP_API_KEY"],
    }
    async with httpx.AsyncClient(timeout=httpx.Timeout(20.0, connect=8.0), follow_redirects=True) as client:
        response = await client.get(FMP_CALENDAR_URL, params=params)
        response.raise_for_status()
        payload = response.json()

    zone = ZoneInfo(os.environ["FMP_EVENT_TIMEZONE"])
    events: list[dict[str, Any]] = []
    if isinstance(payload, list):
        for item in payload:
            if not isinstance(item, dict):
                continue
            title = str(item.get("event", "")).strip()
            raw_time = str(item.get("date", "")).strip()
            if not title or not raw_time:
                continue
            parsed = datetime.fromisoformat(raw_time.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=zone)
            impact_raw = str(item.get("impact", "Medium")).lower()
            impact = "HIGH" if impact_raw in {"high", "3"} else "LOW" if impact_raw in {"low", "1"} else "MEDIUM"
            country = str(item.get("country", ""))
            events.append(
                {
                    "id": hashlib.sha1(f"{title}|{raw_time}|{country}".encode("utf-8")).hexdigest()[:16],
                    "title": title,
                    "currency": str(item.get("currency", "—")),
                    "country": country,
                    "time": parsed.astimezone(timezone.utc).isoformat(),
                    "impact": impact,
                    "actual": str(item.get("actual") if item.get("actual") is not None else "—"),
                    "forecast": str(item.get("estimate") if item.get("estimate") is not None else "—"),
                    "previous": str(item.get("previous") if item.get("previous") is not None else "—"),
                }
            )

    return {
        "source": "FMP Economic Calendar",
        "live": True,
        "retrieved_at": datetime.now(timezone.utc).isoformat(),
        "data": events,
        "notice": "FMP event times converted using FMP_EVENT_TIMEZONE. Confirm this setting against your provider agreement.",
    }


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "trading-news-api", "version": "0.1.0"}


@app.get("/v1/status")
async def status() -> dict[str, Any]:
    calendar_enabled, calendar_notice = calendar_provider_status()
    return {
        "news_provider": "GDELT DOC 2.0",
        "news_enabled": True,
        "calendar_provider": "FMP Economic Calendar",
        "calendar_enabled": calendar_enabled,
        "calendar_notice": calendar_notice,
    }


@app.get("/v1/news")
async def news(category: str = Query(default="all", max_length=24)) -> dict[str, Any]:
    try:
        return await fetch_gdelt_news(category.lower())
    except (httpx.HTTPError, ValueError) as exc:
        return {
            "source": "GDELT DOC 2.0",
            "live": False,
            "data": [],
            "notice": f"News provider temporarily unavailable: {type(exc).__name__}",
        }


@app.get("/v1/calendar")
async def calendar(range: str = Query(default="7d", max_length=8)) -> dict[str, Any]:
    match = re.fullmatch(r"(\d{1,2})d", range.lower())
    days = int(match.group(1)) if match else 7
    try:
        return await fetch_fmp_calendar(days)
    except (httpx.HTTPError, ValueError, KeyError) as exc:
        return {
            "source": "FMP Economic Calendar",
            "live": False,
            "data": [],
            "notice": f"Calendar provider temporarily unavailable: {type(exc).__name__}",
        }
