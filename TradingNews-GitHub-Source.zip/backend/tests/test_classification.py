import unittest

from app.main import classify_category, classify_impact


class ClassificationTests(unittest.TestCase):
    def test_geopolitics(self):
        self.assertEqual(classify_category("New sanctions announced after regional conflict"), "geopolitics")

    def test_energy(self):
        self.assertEqual(classify_category("OPEC discusses oil production"), "energy")

    def test_crypto(self):
        self.assertEqual(classify_category("Bitcoin ETF decision approaches"), "crypto")

    def test_critical_impact(self):
        self.assertEqual(classify_impact("Major bank collapse prompts emergency response"), "CRITICAL")

    def test_high_impact(self):
        self.assertEqual(classify_impact("Central bank signals interest rate change"), "HIGH")


if __name__ == "__main__":
    unittest.main()
