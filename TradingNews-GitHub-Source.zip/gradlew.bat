@echo off
setlocal
set "GRADLE_VERSION=8.13"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_INSTALL=%GRADLE_USER_HOME%\tradingnews-gradle-%GRADLE_VERSION%"

if not exist "%GRADLE_INSTALL%\bin\gradle.bat" (
  echo Gradle %GRADLE_VERSION% is not installed locally. Downloading official distribution...
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop'; $version='%GRADLE_VERSION%'; $base=Join-Path $env:GRADLE_USER_HOME ('tradingnews-gradle-' + $version); $tmp=Join-Path $env:TEMP ('tradingnews-gradle-' + $version); $zip=Join-Path $env:TEMP ('gradle-' + $version + '-bin.zip'); if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }; if (Test-Path $zip) { Remove-Item -Force $zip }; Invoke-WebRequest -Uri ('https://services.gradle.org/distributions/gradle-' + $version + '-bin.zip') -OutFile $zip; Expand-Archive -Path $zip -DestinationPath $tmp -Force; New-Item -ItemType Directory -Force -Path (Split-Path $base) | Out-Null; if (Test-Path $base) { Remove-Item -Recurse -Force $base }; Move-Item -Path (Join-Path $tmp ('gradle-' + $version)) -Destination $base; Remove-Item -Recurse -Force $tmp; Remove-Item -Force $zip"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_INSTALL%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
