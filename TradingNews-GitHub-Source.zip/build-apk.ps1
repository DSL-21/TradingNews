$ErrorActionPreference = 'Stop'

$java = Get-Command java -ErrorAction SilentlyContinue
if (-not $java) {
    throw 'JDK 17 or newer was not found. Install Android Studio or a JDK 17+ distribution.'
}

& (Join-Path $PSScriptRoot 'gradlew.bat') :app:assembleDebug
if ($LASTEXITCODE -ne 0) {
    throw "Gradle build failed with exit code $LASTEXITCODE."
}

$apk = Join-Path $PSScriptRoot 'app/build/outputs/apk/debug/app-debug.apk'
if (Test-Path $apk) {
    Write-Host "APK created: $apk" -ForegroundColor Green
} else {
    throw 'Gradle completed but the expected APK file was not found.'
}
