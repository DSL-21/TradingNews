# Trading News — Android MVP 0.1.0

A dark-mode Android market-news and economic-calendar prototype. The repository includes:

- Native Android app built with Kotlin + Jetpack Compose.
- Dashboard, Economic Calendar, Breaking News, and Settings screens.
- Currency, impact, and category filters.
- Local demo data that is visibly labelled DEMO (it is not live market information).
- Configurable HTTPS backend URL; provider keys are never embedded in the APK.
- Android notification permission flow and best-effort event reminders using WorkManager.
- FastAPI backend with GDELT DOC 2.0 headline aggregation and a separately gated FMP economic-calendar adapter.

## Important: what is live and what is not

The Android app starts in **DEMO** mode until it is connected to a backend. The demo cards are illustrative only and must not be treated as current events or trading signals.

The backend's GDELT connector is implemented for global headline discovery. It returns headline, publisher domain, timestamp, category, an estimated impact label, and a link to the original publisher. It does not republish article bodies. GDELT's API documentation describes article-list output and coverage/search across many languages: <https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/>.

The economic calendar connector is deliberately disabled by default. The FMP API documentation lists an Economic Data Releases Calendar endpoint, but FMP's pricing information says displaying or redistributing FMP data requires a specific Data Display and Licensing Agreement. Before enabling it for a public app, obtain the correct plan and written display/redistribution permission. Then set `FMP_DATA_DISPLAY_LICENSED=true` on the backend and configure the event timezone only after confirming it with the provider. References:

- <https://site.financialmodelingprep.com/developer/docs>
- <https://site.financialmodelingprep.com/pricing-plans>

Forex Factory is **not scraped or consumed through an undocumented export** in this public-facing starter. The weekly calendar page provides visible ICS/CSV/JSON/XML export controls, but that alone is not a redistribution licence or a documented public API. Obtain written permission before using its calendar feed inside a public app. Reference: <https://www.forexfactory.com/calendar>.

## Project layout

```text
TradingNews-v1/
  app/                         Android application
  backend/                     FastAPI aggregation service
  docs/                        Privacy and release notes
  README.md
  settings.gradle.kts
  build.gradle.kts
```

## Build the Android APK with GitHub Actions (recommended)

The repository includes `.github/workflows/android-apk.yml`. It builds an installable debug APK on a GitHub-hosted runner, so Android SDK and Gradle do not need to be installed on your own PC. It runs after changes to the Android app on `main`/`master`, and can also be started manually.

1. Create a GitHub repository.
2. Upload **the contents of this project folder** to the repository root (the `.github` folder must be directly at the repository root, not nested under another `TradingNews-v1` folder).
3. Open the repository's **Actions** tab and select **Build Trading News APK**.
4. Choose **Run workflow** for a manual build, or wait for the build after pushing the project.
5. Open the completed workflow run and download the `TradingNews-debug-apk` artifact. Extract it to get `app-debug.apk`.
6. Transfer the APK to the Android phone and install it. Android may ask you to allow installation from that file manager/browser.

The output is a **debug APK for testing**. It is installable, but it is not a production-signed release for Google Play. A public release needs a protected signing key and a separate release workflow.

## Build the Android APK locally

This environment did not contain Android SDK or Gradle, and outbound package downloads were unavailable. Therefore an APK could not be built or tested here. The Android source project is prepared for Android Studio.

On a Windows PC:

1. Install the current stable Android Studio and Android SDK Platform 36.
2. Open this folder (`TradingNews-v1`) in Android Studio.
3. Run `.\gradlew.bat --version` once in PowerShell; the included bootstrap script downloads the official Gradle 8.13 distribution if needed. Android Studio can then use the same local Gradle installation.
4. Allow Gradle sync to download the Android Gradle Plugin and AndroidX dependencies.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will create the debug APK at `app/build/outputs/apk/debug/app-debug.apk` (debug package suffix: `.debug`).

Alternatively, run the included wrapper bootstrap directly:

```powershell
.\gradlew.bat :app:assembleDebug
```

The release build requires normal app signing configuration before distribution. Do not distribute a debug APK as a production release.

## Run the backend (no Docker)

Python 3.11+ is recommended.

### Windows PowerShell

```powershell
cd backend
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

### Linux VPS

```bash
cd backend
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

For production, run the process under a service manager (for example systemd) and put it behind an HTTPS reverse proxy. Do not expose a plain HTTP backend over the public internet. Configure `CORS_ORIGINS` for the web clients you actually deploy; native Android does not use browser CORS enforcement.

### Backend configuration

The GDELT headline feed works without an API key, subject to the provider's fair-use availability and API behaviour. The backend caches results for three minutes by default.

Economic calendar settings are intentionally opt-in:

```env
FMP_API_KEY=your_server_side_key
FMP_DATA_DISPLAY_LICENSED=false
FMP_EVENT_TIMEZONE=
```

Only after the appropriate FMP display/redistribution agreement has been signed should the owner set `FMP_DATA_DISPLAY_LICENSED=true`. Set `FMP_EVENT_TIMEZONE` to the IANA timezone that the provider confirms for its event timestamps (for example, a verified `America/New_York` value); do not guess. The backend converts that configured provider-local time to UTC before the app displays it in the phone's local timezone and schedules reminders.

Never place provider API keys in the Android source code, APK, Git repository, or client settings.

## Connect the app

1. Deploy the backend behind HTTPS (for example `https://api.yourdomain.example`).
2. Install the app and open **Nastavení**.
3. Enter the backend HTTPS URL and tap **Uložit a připojit**.
4. The header shows separate `NEWS LIVE/DEMO` and `CALENDAR LIVE/DEMO` statuses.

The calendar stays in DEMO until a licensed provider and a confirmed timezone are configured. News can be live independently.

## Notification behaviour

The app schedules reminders only for live calendar events and only when an alert interval is enabled. It uses WorkManager's delayed work, which is **best-effort, not an exact alarm**. Android Doze mode, battery restrictions, force-stop behaviour, and notification permission can delay or suppress delivery. Do not use these reminders as guaranteed execution timing for an automated trading strategy.

## Classification limitations

The first backend labels categories and estimated market impact using transparent keyword rules. This is a triage aid, not a validated market-impact model. A headline may be duplicated, incomplete, misleading, or unrelated to the market in question. The app links to the original publisher and does not infer a guaranteed price direction.

## Public release checklist

Before publishing to Google Play or distributing an APK publicly:

- Secure the backend with HTTPS, monitoring, rate limits, caching, and abuse protection.
- Obtain written data-display/redistribution permission for each provider and territory. Publicly accessible data is not automatically free to redistribute.
- Publish a real privacy policy and contact details; the included template is not a final legal document.
- Complete Google Play's Data safety and any applicable Financial features declarations.
- Verify all event timezone handling, daylight-saving transitions, and data refresh behaviour.
- Review third-party publisher attribution requirements and keep article content at its original publisher.
- Configure production app signing, package identity, store listing, support channel, and incident contact.
- Replace keyword-only impact classification with a documented and tested methodology before presenting it as a robust rating.

## Versioning

- App version: `0.1.0`
- Android versionCode: `1`
- Package: `com.tradingnews.app` (`.debug` suffix in debug builds)
